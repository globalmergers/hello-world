import { Component, OnInit } from '@angular/core';
declare var particlesJS: any;
declare var Particles: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.particle();
    this.slider();
  }

  particle(): void {
    try {
      Particles.init({
        selector: '.background',
        color: '#326CF4',
        context: "3d",
        maxParticles: 80,
        sizeVariations: 5,
        speed: 1,
        connectParticles: true,
        responsive: [
          {
            maxParticles: 20,
            breakpoint: 500,
            options: {
              maxParticles: 40
            }
          }, {
            maxParticles: 20,
            breakpoint: 500,
            options: {
              maxParticles: 50
            }
          }
        ]
      });
    } catch (e) {
      console.info(e);
    }
  }

  slider(): void {
    try {
      (async function () {
        // var t0 = performance.now();
        setInterval(async function () {
          var parent: any = document.querySelector('.ticker1-track');
          var slide: any = parent?.querySelectorAll('.item');
          var y = window.matchMedia("(max-width: 700px)")
          // x.addListener(myFunction);
          for (var i = 0; i < slide?.length; i++) {
            if (y.matches) {
              var x = await slide[i];
              x.classList.toggle('sliding-now');
              if (i == 4) {
                var x = await slide[i];
                await x.classList.remove('adjacent');
                await x.classList.add('active');
              }
              if (i == 3 || i == 5) {
                var x = await slide[i];
                await x.classList.remove('active');
                await x.classList.add('adjacent');
              } else {
                var x = await slide[i];
                await x.classList.remove('adjacent');
              }
              if (i != 4) {
                var x = await slide[i];
                await x.classList.remove('active');
              }
            } else {
              var x = await slide[i];
              x.classList.toggle('sliding-now');
              if (i == 3) {
                var x = await slide[i];
                await x.classList.remove('adjacent');
                await x.classList.add('active');
              }
              if (i == 2 || i == 4) {
                var x = await slide[i];
                await x.classList.remove('active');
                await x.classList.add('adjacent');
              } else {
                var x = await slide[i];
                await x.classList.remove('adjacent');
              }
              if (i != 3) {
                var x = await slide[i];
                await x.classList.remove('active');
              }
            }
          }

          setTimeout(function () {
            parent?.appendChild(slide[0]);
          }, 5);

        }, 2000);
      })()
    } catch (e) {
      console.info(e);
    }
  }

}
